<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta name="distribution" content="global"/>
<meta name="author" content="Blendman"/>
<meta name="copyright" content="Copyright (c) Blendman 2016. "/>
<meta name="description" content="Cartoon, a vector drawing and animation tool, made in purebasic."/>
<link rel="stylesheet" type="text/css" href="style.css"/>
<title>Cartoon : a vector tool for drawing, Comics, Games and Animation..</title>
<link href="icon.ico" rel="SHORTCUT ICON"/>